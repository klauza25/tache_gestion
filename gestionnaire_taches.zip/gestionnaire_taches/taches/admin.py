from django.contrib import admin
from .models import Categorie, Tache

admin.site.register(Categorie)
admin.site.register(Tache)