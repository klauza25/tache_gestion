from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('liste', views.liste, name='liste_taches'),
    path('<int:tache_id>/', views.detail_tache, name='detail_tache'),
    path('creer/', views.creer_tache, name='creer_tache'),
    path('<int:tache_id>/editer/', views.editer_tache, name='editer_tache'),
    path('<int:tache_id>/supprimer/', views.supprimer_tache, name='supprimer_tache'),
    path('contact', views.about, name='contact'),
]
