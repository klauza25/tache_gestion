from django.shortcuts import render, get_object_or_404, redirect
from .models import Categorie, Tache
from .forms import TacheForm


def index(request):

    return render(request, 'taches/index.html')


def liste(request):
    query = request.GET.get('q')
    if query:
        taches = Tache.objects.filter(nom__icontains=query) 
    else:
        taches = Tache.objects.all()
    return render(request, 'taches/liste.html', {'taches': taches})

def detail_tache(request, tache_id):
    t = get_object_or_404(Tache, id=tache_id)
    return render(request, 'taches/detail_tache.html', {'tache': t})

def creer_tache(request):
    if request.method == "POST":
        form = TacheForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('liste_taches')
    else:
        form = TacheForm()
    return render(request, 'taches/creer_tache.html', {'form': form})

def editer_tache(request, tache_id):
    tache = get_object_or_404(Tache, id=tache_id)
    if request.method == "POST":
        form = TacheForm(request.POST, instance=tache)
        if form.is_valid():
            form.save()
            return redirect('detail_tache', tache_id=tache.id)
    else:
        form = TacheForm(instance=tache)
    return render(request, 'taches/editer_tache.html', {'form': form, 'tache': tache})

def supprimer_tache(request, tache_id):
    tache = get_object_or_404(Tache, id=tache_id)
    if request.method == "POST":
        tache.delete()
        return redirect('liste_taches')
    return render(request, 'taches/supprimer_tache.html', {'tache': tache})

def about(request):

    return render(request, 'taches/contact.html')
